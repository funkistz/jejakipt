import { Injectable } from '@angular/core';

@Injectable()
export class DataSource {

  public source:any[] = [];
  public tempdata:any = '';

}
